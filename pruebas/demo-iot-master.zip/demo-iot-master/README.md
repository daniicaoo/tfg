# demo-iot
Demo sencilla para demostrar la potencia de Arduino + Raspberry Pi + Node-RED
